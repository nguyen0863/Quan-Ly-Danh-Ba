﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;

namespace Library
{
    [ServiceContract]
    public interface IQuanLyDanhBa
    {
        [OperationContract]
        bool checklogin(string userID, string password);

        [OperationContract]
        DataSet getglobalcontact();

        [OperationContract]
        DataSet getfriend(string UseID);

        #region OperationContractContact
        [OperationContract]
        void addcontact(Contactparameter cp, Groupparameter gp, Userparameter up);

        [OperationContract]
        void editcontact(Contactparameter cp, Groupparameter gp, string updategroupname, string updatecontactname, string updateuserid);

        [OperationContract]
        void deletecontact(Contactparameter cp);
        #endregion

        #region OperationContractGroup
        [OperationContract]
        void addgroup(Groupparameter gp, Userparameter up);

        [OperationContract]
        void editgroup(Groupparameter gp);

        [OperationContract]
        void deletegroup(Groupparameter gp);
        #endregion

        //[OperationContract]
        //List<string[]> getgroupid();

        [OperationContract]
        DataSet getgroupname(string UserID);

        [OperationContract]
        DataSet getcontact(string UserID);

        [OperationContract]
        DataSet getuserid(string UserID);
    }

    #region Properties
    [DataContract]
    public class Contactparameter
    {
        private string contactname;
        private string phonenumber;
        private string address;
        private string email;
        private string groupname;
        private string userid;
        private bool isdeleted;

        [DataMember]
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        [DataMember]
        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        [DataMember]
        public string Phonenumber
        {
            get { return phonenumber; }
            set { phonenumber = value; }
        }

        [DataMember]
        public string Contactname
        {
            get { return contactname; }
            set { contactname = value; }
        }

        [DataMember]
        public bool Isdeleted
        {
            get { return isdeleted; }
            set { isdeleted = value; }
        }

        [DataMember]
        public string Groupname
        {
            get { return groupname; }
            set { groupname = value; }
        }

        [DataMember]
        public string Userid
        {
            get { return userid; }
            set { userid = value; }
        }
    }

    [DataContract]
    public class Groupparameter
    {
        private string groupname;
        private bool isdeleted;

        [DataMember]
        public string Groupname
        {
            get { return groupname; }
            set { groupname = value; }
        }

        [DataMember]
        public bool Isdeleted
        {
            get { return isdeleted; }
            set { isdeleted = value; }
        }
    }

    [DataContract]
    public class Userparameter
    {
        private string userid;
        private string password;
        private string username;
        private bool isdeleted;

        [DataMember]
        public string Userid
        {
            get { return userid; }
            set { userid = value; }
        }

        [DataMember]
        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        [DataMember]
        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        [DataMember]
        public bool Isdeleted
        {
            get { return isdeleted; }
            set { isdeleted = value; }
        }
    }
#endregion
}
