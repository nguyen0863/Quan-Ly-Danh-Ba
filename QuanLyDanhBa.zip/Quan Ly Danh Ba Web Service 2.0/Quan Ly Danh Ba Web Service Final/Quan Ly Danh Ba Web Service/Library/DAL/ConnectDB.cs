﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace Library.DAL
{
    class ConnectDB
    {
        SqlConnection getConnect()
        {
            return new SqlConnection("Data Source=(local);Initial Catalog=QuanLyDanhBa;Integrated Security=True");
        }
        //Get table function
        public DataTable getTable(string sql)
        {
            DataTable table = new DataTable();
            try
            {

                SqlConnection con = getConnect();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, con);
                dataAdapter.Fill(table);
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                throw ex;
            }
            return table;
        }
        //Execute one statement without value return
        public void executeNonQuery(string sql)
        {
            try
            {
                SqlConnection con = getConnect();
                con.Open();
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Dữ liệu đã tồn tại!!!");
            }
        }
        //DataAdapter
        public SqlDataAdapter dataAdapter(string sql)
        {
            SqlConnection con = getConnect();
            return new SqlDataAdapter(sql, con);
        }

    }
}
