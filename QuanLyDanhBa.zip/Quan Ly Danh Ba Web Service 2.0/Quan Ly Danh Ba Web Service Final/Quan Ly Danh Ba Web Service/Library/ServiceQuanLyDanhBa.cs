﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Library.DAL;
using System.Data;

namespace Library
{
    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class ServiceQuanLyDanhBa : IQuanLyDanhBa
    {
        ConnectDB con = new ConnectDB();
        public bool checklogin(string userID, string password)
        {
            bool b = false;
            DataTable dt = con.getTable("select UserID, [Password] from [User]");
            foreach (DataRow r in dt.Rows)
            {
                if (r[0].ToString() == userID && r[1].ToString() == password)
                    b = true;
            }
            return b;
        }

        #region ContactBehavior
        public void addcontact(Contactparameter cp, Groupparameter gp, Userparameter up)
        {
            con.executeNonQuery(String.Format("insert into dbo.[Contact](ContactName,PhoneNumber,Address,Email,GroupName,UserID) values(N'{0}','{1}',N'{2}',N'{3}',N'{4}',N'{5}')", cp.Contactname, cp.Phonenumber, cp.Address, cp.Email, gp.Groupname, up.Userid));
        }

        public void editcontact(Contactparameter cp, Groupparameter gp, string updategroupname, string updatecontactname, string updateuserid)
        {
            con.executeNonQuery(String.Format("update Contact set ContactName = '"+cp.Contactname+"', PhoneNumber = '"+cp.Phonenumber+"', [Address] = '"+cp.Address+"', Email = '"+cp.Email+"', GroupName = '"+cp.Groupname+"', IsDeleted = 0 where ContactName = '"+updatecontactname+"' AND GroupName = '"+updategroupname+"' AND UserID = '"+updateuserid+"'"));
        }

        public void deletecontact(Contactparameter cp)
        {
            con.executeNonQuery(String.Format("update Contact set IsDeleted = 'true' where Phonenumber = '{0}' and GroupName = '{1}' and UserID = '{2}'", cp.Phonenumber, cp.Groupname, cp.Userid));
        }
        #endregion

        #region GroupBehavior
        public void addgroup(Groupparameter gp, Userparameter up)
        {
            try
            {
                con.executeNonQuery(String.Format("insert into dbo.[Group](GroupName) values('{0}')", gp.Groupname));
                con.executeNonQuery(String.Format("insert into dbo.[Group_User](GroupName , UserID) values('{0}','{1}')", gp.Groupname, up.Userid));
            }
            catch
            {
                con.executeNonQuery(String.Format("insert into dbo.[Group_User](GroupName , UserID) values('{0}','{1}')", gp.Groupname, up.Userid));
            }
        }

        public void editgroup(Groupparameter gp)
        {
            con.executeNonQuery(String.Format("update dbo.[Group] set GroupName = '{0}' where GroupName = '{1}'", gp.Groupname, gp.Groupname));
        }

        public void deletegroup(Groupparameter gp)
        {
            con.executeNonQuery(String.Format("update dbo.[Group] set IsDeleted = 'true' where GroupName = '{0}'", gp.Groupname));
        }

        #endregion

        //public List<string[]> getgroupid()
        //{
        //    DataTable dt = con.getTable("select GroupID, GroupName from dbo.[Group] where IsDeleted = 0");
        //    List<string[]> l = new List<string[]>();
        //    string[] t = new string[2];
        //    foreach(DataRow r in dt.Rows)
        //    {
        //        t[0] = r[0].ToString();
        //        t[1] = r[1].ToString();
        //        l.Add(t);
        //    }
        //    return l;
        //}

        public DataSet getgroupname(string UserID)
        {
            DataTable dt = con.getTable("select Group_User.GroupName, Group_User.UserID  from [Group], Group_User where [Group].GroupName = Group_User.GroupName AND UserID = '"+ UserID +"' AND [Group].IsDeleted = 0");
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        public DataSet getcontact(string UserID)
        {
            DataTable dt = con.getTable("select * from dbo.[Contact] where IsDeleted = 0 and UserID = '"+UserID+"'");
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        public DataSet getuserid(string UserID)
        {
            DataTable dt = con.getTable("select * from dbo.[User] where IsDeleted = 0 and UserID = '"+UserID+"'");
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        public DataSet getglobalcontact()
        {
            DataTable dt = con.getTable("select * from dbo.[GlobalContact] where IsDeleted = 0");
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }

        public DataSet getfriend(string UserID)
        {
            DataTable dt = con.getTable("select UserID2 from dbo.[Friend] where UserID1 = '"+UserID+"'");
            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            return ds;
        }
    }
}
