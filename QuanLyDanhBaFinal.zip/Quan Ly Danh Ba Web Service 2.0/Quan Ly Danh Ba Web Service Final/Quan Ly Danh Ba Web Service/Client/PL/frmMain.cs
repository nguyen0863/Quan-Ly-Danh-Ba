﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraBars;
using Client.PL.Contact;
using Client.PL.Group;

namespace Client.PL
{
    public partial class frmMain : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public static string _UserId = "";
        public frmMain()
        {
            InitializeComponent();
        }

        frmContact fContact;
        frmGroup fGroup;
        frmGlobalContact fGlobalContact;

        private int isexist_form(string formname)
        {
            int t = -1;
            int i;
            for (i = 0; i < this.MdiChildren.Length; i++)
            {
                if (MdiChildren[i].Name == formname)
                    t = i;
            }
            return t;
        }

        private void btnContact_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (isexist_form("frmContact") == -1)
            {
                fContact = new frmContact();
                fContact.MdiParent = this;
                fContact.Show();
            }
            else
            {
                MdiChildren[isexist_form("frmContact")].Activate();
            }
        }

        private void btnGroup_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (isexist_form("frmGroup") == -1)
            {
                fGroup = new frmGroup();
                fGroup.MdiParent = this;
                fGroup.Show();
            }
            else
            {
                MdiChildren[isexist_form("frmGroup")].Activate();
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            frmLogin f = new frmLogin();
            f.ShowDialog();
        }

        private void btnGlobalContact_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (isexist_form("frmGrobalContact") == -1)
            {
                fGlobalContact = new frmGlobalContact();
                fGlobalContact.MdiParent = this;
                fGlobalContact.Show();
            }
            else
            {
                MdiChildren[isexist_form("frmGrobalContact")].Activate();
            }
        }
    }
}