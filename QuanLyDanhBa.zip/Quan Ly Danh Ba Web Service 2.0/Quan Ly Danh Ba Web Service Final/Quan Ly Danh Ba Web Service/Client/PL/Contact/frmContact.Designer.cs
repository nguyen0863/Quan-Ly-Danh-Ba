﻿namespace Client.PL.Contact
{
    partial class frmContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContact));
            this.backstageViewControl1 = new DevExpress.XtraBars.Ribbon.BackstageViewControl();
            this.btnAddContact = new DevExpress.XtraBars.Ribbon.BackstageViewButtonItem();
            this.btnDeleteContact = new DevExpress.XtraBars.Ribbon.BackstageViewButtonItem();
            this.btnEditContact = new DevExpress.XtraBars.Ribbon.BackstageViewButtonItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGetFriendContact = new DevExpress.XtraEditors.SimpleButton();
            this.cbbListFriend = new System.Windows.Forms.ComboBox();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colContactName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPhoneNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colAddress = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colEmail = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGroupName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUserID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemRadioGroup1 = new DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroup1)).BeginInit();
            this.SuspendLayout();
            // 
            // backstageViewControl1
            // 
            this.backstageViewControl1.ColorScheme = DevExpress.XtraBars.Ribbon.RibbonControlColorScheme.Yellow;
            this.backstageViewControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.backstageViewControl1.Items.Add(this.btnAddContact);
            this.backstageViewControl1.Items.Add(this.btnDeleteContact);
            this.backstageViewControl1.Items.Add(this.btnEditContact);
            this.backstageViewControl1.LeftPaneMinWidth = 179;
            this.backstageViewControl1.Location = new System.Drawing.Point(0, 0);
            this.backstageViewControl1.Name = "backstageViewControl1";
            this.backstageViewControl1.SelectedTab = null;
            this.backstageViewControl1.Size = new System.Drawing.Size(180, 409);
            this.backstageViewControl1.TabIndex = 0;
            this.backstageViewControl1.Text = "backstageViewControl1";
            // 
            // btnAddContact
            // 
            this.btnAddContact.Caption = "Add Contact";
            this.btnAddContact.Glyph = ((System.Drawing.Image)(resources.GetObject("btnAddContact.Glyph")));
            this.btnAddContact.Name = "btnAddContact";
            this.btnAddContact.ItemClick += new DevExpress.XtraBars.Ribbon.BackstageViewItemEventHandler(this.btnAddContact_ItemClick);
            // 
            // btnDeleteContact
            // 
            this.btnDeleteContact.Caption = "Delete Contact";
            this.btnDeleteContact.Glyph = ((System.Drawing.Image)(resources.GetObject("btnDeleteContact.Glyph")));
            this.btnDeleteContact.Name = "btnDeleteContact";
            this.btnDeleteContact.ItemClick += new DevExpress.XtraBars.Ribbon.BackstageViewItemEventHandler(this.btnDeleteContact_ItemClick);
            // 
            // btnEditContact
            // 
            this.btnEditContact.Caption = "Edit Contact";
            this.btnEditContact.Glyph = global::Client.Properties.Resources.user_edit;
            this.btnEditContact.Name = "btnEditContact";
            this.btnEditContact.ItemClick += new DevExpress.XtraBars.Ribbon.BackstageViewItemEventHandler(this.btnEditContact_ItemClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnGetFriendContact);
            this.panel1.Controls.Add(this.cbbListFriend);
            this.panel1.Controls.Add(this.backstageViewControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(180, 409);
            this.panel1.TabIndex = 1;
            // 
            // btnGetFriendContact
            // 
            this.btnGetFriendContact.Location = new System.Drawing.Point(21, 172);
            this.btnGetFriendContact.Name = "btnGetFriendContact";
            this.btnGetFriendContact.Size = new System.Drawing.Size(121, 23);
            this.btnGetFriendContact.TabIndex = 2;
            this.btnGetFriendContact.Text = "Get Friend Contact";
            this.btnGetFriendContact.Click += new System.EventHandler(this.btnGetFriendContact_Click);
            // 
            // cbbListFriend
            // 
            this.cbbListFriend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbListFriend.FormattingEnabled = true;
            this.cbbListFriend.Location = new System.Drawing.Point(21, 145);
            this.cbbListFriend.Name = "cbbListFriend";
            this.cbbListFriend.Size = new System.Drawing.Size(121, 21);
            this.cbbListFriend.TabIndex = 1;
            this.cbbListFriend.Click += new System.EventHandler(this.cbbListFriend_Click);
            // 
            // gridControl1
            // 
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl1.Location = new System.Drawing.Point(180, 0);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.repositoryItemRadioGroup1});
            this.gridControl1.Size = new System.Drawing.Size(660, 409);
            this.gridControl1.TabIndex = 2;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            this.gridControl1.DoubleClick += new System.EventHandler(this.gridControl1_DoubleClick);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colContactName,
            this.colPhoneNumber,
            this.colAddress,
            this.colEmail,
            this.colGroupName,
            this.colUserID});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsFind.FindDelay = 100;
            this.gridView1.OptionsFind.FindMode = DevExpress.XtraEditors.FindMode.Always;
            // 
            // colContactName
            // 
            this.colContactName.Caption = "Contact Name";
            this.colContactName.CustomizationCaption = "Contact Name";
            this.colContactName.FieldName = "ContactName";
            this.colContactName.Name = "colContactName";
            this.colContactName.OptionsColumn.AllowEdit = false;
            this.colContactName.Visible = true;
            this.colContactName.VisibleIndex = 0;
            this.colContactName.Width = 98;
            // 
            // colPhoneNumber
            // 
            this.colPhoneNumber.Caption = "Phone Number";
            this.colPhoneNumber.CustomizationCaption = "Phone Number";
            this.colPhoneNumber.FieldName = "PhoneNumber";
            this.colPhoneNumber.Name = "colPhoneNumber";
            this.colPhoneNumber.OptionsColumn.AllowEdit = false;
            this.colPhoneNumber.Visible = true;
            this.colPhoneNumber.VisibleIndex = 1;
            this.colPhoneNumber.Width = 98;
            // 
            // colAddress
            // 
            this.colAddress.Caption = "Address";
            this.colAddress.CustomizationCaption = "Address";
            this.colAddress.FieldName = "Address";
            this.colAddress.Name = "colAddress";
            this.colAddress.OptionsColumn.AllowEdit = false;
            this.colAddress.Visible = true;
            this.colAddress.VisibleIndex = 2;
            this.colAddress.Width = 98;
            // 
            // colEmail
            // 
            this.colEmail.Caption = "Email";
            this.colEmail.CustomizationCaption = "Email";
            this.colEmail.FieldName = "Email";
            this.colEmail.Name = "colEmail";
            this.colEmail.OptionsColumn.AllowEdit = false;
            this.colEmail.Visible = true;
            this.colEmail.VisibleIndex = 3;
            this.colEmail.Width = 98;
            // 
            // colGroupName
            // 
            this.colGroupName.Caption = "Group Name";
            this.colGroupName.CustomizationCaption = "Group Name";
            this.colGroupName.FieldName = "GroupName";
            this.colGroupName.Name = "colGroupName";
            this.colGroupName.OptionsColumn.AllowEdit = false;
            this.colGroupName.Visible = true;
            this.colGroupName.VisibleIndex = 4;
            this.colGroupName.Width = 98;
            // 
            // colUserID
            // 
            this.colUserID.Caption = "User ID";
            this.colUserID.FieldName = "UserID";
            this.colUserID.Name = "colUserID";
            this.colUserID.OptionsColumn.AllowEdit = false;
            this.colUserID.Visible = true;
            this.colUserID.VisibleIndex = 5;
            this.colUserID.Width = 106;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemRadioGroup1
            // 
            this.repositoryItemRadioGroup1.Name = "repositoryItemRadioGroup1";
            // 
            // frmContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 409);
            this.ControlBox = false;
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmContact";
            this.Text = "frmContact";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.frmContact_Activated);
            this.Load += new System.EventHandler(this.frmContact_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroup1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.BackstageViewControl backstageViewControl1;
        private DevExpress.XtraBars.Ribbon.BackstageViewButtonItem btnAddContact;
        private DevExpress.XtraBars.Ribbon.BackstageViewButtonItem btnDeleteContact;
        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraBars.Ribbon.BackstageViewButtonItem btnEditContact;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn colContactName;
        private DevExpress.XtraGrid.Columns.GridColumn colPhoneNumber;
        private DevExpress.XtraGrid.Columns.GridColumn colAddress;
        private DevExpress.XtraGrid.Columns.GridColumn colEmail;
        private DevExpress.XtraGrid.Columns.GridColumn colGroupName;
        private DevExpress.XtraGrid.Columns.GridColumn colUserID;
        public DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup repositoryItemRadioGroup1;
        private System.Windows.Forms.ComboBox cbbListFriend;
        private DevExpress.XtraEditors.SimpleButton btnGetFriendContact;
    }
}