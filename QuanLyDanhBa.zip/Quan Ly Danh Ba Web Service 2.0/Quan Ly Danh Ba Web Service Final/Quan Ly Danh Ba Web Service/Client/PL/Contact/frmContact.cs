﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.ServiceModel;
using Library.DAL;

namespace Client.PL.Contact
{
    public partial class frmContact : DevExpress.XtraEditors.XtraForm
    {
        Library.Contactparameter cp = new Library.Contactparameter();
        Library.Groupparameter gp = new Library.Groupparameter();
        public static string _UserFriend;
        frmFriendContact fFriendContact;

        public frmContact()
        {
            InitializeComponent();
        }

        private void btnDeleteContact_ItemClick(object sender, DevExpress.XtraBars.Ribbon.BackstageViewItemEventArgs e)
        {
            //gridView1.MoveNext();
            //gridView1.MovePrev();
            try
            {
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                cp.Phonenumber = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colPhoneNumber).ToString();
                cp.Groupname = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colGroupName).ToString();
                cp.Userid = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colUserID).ToString();
                proxy.deletecontact(cp);
                gridView1.DeleteRow(gridView1.FocusedRowHandle);
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void frmContact_Load(object sender, EventArgs e)
        {
            //load du lieu vao gridcontrol
            try
            {
                //cbbGroupID : đã binding với database, display value là group name, value là group id
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                gridControl1.DataSource = proxy.getcontact(frmMain._UserId).Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void btnAddContact_ItemClick(object sender, DevExpress.XtraBars.Ribbon.BackstageViewItemEventArgs e)
        {
            frmAddContact fac = new frmAddContact();
            fac.ShowDialog();
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            gridControl1.DataSource = proxy.getcontact(frmMain._UserId).Tables[0];
        }

        private void gridControl1_DoubleClick(object sender, EventArgs e)
        {
            
        }

        private void btnEditContact_ItemClick(object sender, DevExpress.XtraBars.Ribbon.BackstageViewItemEventArgs e)
        {
            try
            {
                cp.Phonenumber = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colPhoneNumber).ToString();
                cp.Groupname = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colGroupName).ToString();
                cp.Address = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colAddress).ToString();
                cp.Contactname = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colContactName).ToString();
                cp.Email = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colEmail).ToString();
                cp.Userid = frmMain._UserId;
                using (frmEditContact fec = new frmEditContact(cp.Contactname, cp.Phonenumber, cp.Address, cp.Email, cp.Groupname, cp.Userid))
                {
                    fec.ShowDialog();
                }
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                gridControl1.DataSource = proxy.getcontact(frmMain._UserId).Tables[0];
            }
            catch { MessageBox.Show("Vui lòng click vào dòng contact cần edit"); }
        }

        private void cbbListFriend_Click(object sender, EventArgs e)
        {
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            DataSet t = proxy.getfriend(frmMain._UserId);
            cbbListFriend.DataSource = t.Tables[0];
            cbbListFriend.DisplayMember = "UserID2";
            cbbListFriend.ValueMember = "UserID2";
        }

        private void btnGetFriendContact_Click(object sender, EventArgs e)
        {
            _UserFriend = cbbListFriend.Text;
            fFriendContact = new frmFriendContact();
            fFriendContact.ShowDialog();
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            gridControl1.DataSource = proxy.getcontact(frmMain._UserId).Tables[0];
        }

        private void frmContact_Activated(object sender, EventArgs e)
        {
            try
            {
                //cbbGroupID : đã binding với database, display value là group name, value là group id
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                gridControl1.DataSource = proxy.getcontact(frmMain._UserId).Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }
    }
}