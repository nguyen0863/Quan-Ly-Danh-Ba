﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.ServiceModel;
using Library.DAL;


namespace Client.PL.Group
{
    public partial class frmEditGroup : DevExpress.XtraEditors.XtraForm
    {
        Library.Contactparameter cp = new Library.Contactparameter();
        Library.Groupparameter gp = new Library.Groupparameter();
        Library.Userparameter up = new Library.Userparameter();

        public frmEditGroup()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //cbbGroupID : đã binding với database, display value là group name, value là group id
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                gp.Groupname = txtGroupName.Text;
                proxy.editgroup(gp);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void cbbGroup_Click(object sender, EventArgs e)
        {
            //ngay cả khi group mới đc tạo thì vẫn đảm bảo dữ liệu là mới
            //refresh database bảng group
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            DataSet t = proxy.getuserid(frmMain._UserId);
            cbbGroup.DataSource = t.Tables[0];
            cbbGroup.DisplayMember = "UserID";
            cbbGroup.ValueMember = "UserID";
        }
    }
}