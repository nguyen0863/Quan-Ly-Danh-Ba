﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.ServiceModel;

namespace Client.PL
{
    public partial class frmLogin : DevExpress.XtraEditors.XtraForm
    {
        static public string _UserID;
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            if (proxy.checklogin(txtUserID.Text, txtPassword.Text) == false)
                MessageBox.Show("Login failed");
            else
            {
                frmMain._UserId = txtUserID.Text;
                this.Close();
            }
        }
    }
}