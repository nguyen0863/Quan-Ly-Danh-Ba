﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.ServiceModel;
using Client.PL.Contact;

namespace Client.PL
{
    public partial class frmFriendContact : DevExpress.XtraEditors.XtraForm
    {
        Library.Contactparameter cp = new Library.Contactparameter();
        Library.Groupparameter gp = new Library.Groupparameter();
        Library.Userparameter up = new Library.Userparameter();

        public frmFriendContact()
        {
            InitializeComponent();
        }

        private void frmGlobalContact_Load(object sender, EventArgs e)
        {
            try
            {
                //cbbGroupID : đã binding với database, display value là group name, value là group id
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                gridControl1.DataSource = proxy.getcontact(frmContact._UserFriend).Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void btnAddContact_Click(object sender, EventArgs e)
        {
            cp.Phonenumber = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colPhoneNumber).ToString();
            //cp.Groupname = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colGroupName).ToString();
            cp.Address = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colAddress).ToString();
            cp.Contactname = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colContactName).ToString();
            cp.Email = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colEmail).ToString();
            //cp.Userid = frmMain._UserId;
            frmAddContact f = new frmAddContact(cp.Contactname,cp.Phonenumber,cp.Address,cp.Email);
            f.ShowDialog();
        }
    }
}