﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.ServiceModel;
using Library.DAL;

namespace Client.PL.Contact
{
	public partial class frmAddContact: DevExpress.XtraEditors.XtraForm
	{
        Library.Contactparameter cp = new Library.Contactparameter();
        Library.Groupparameter gp = new Library.Groupparameter();
        Library.Userparameter up = new Library.Userparameter();
        
        public frmAddContact()
		{
            InitializeComponent();
		}

        string cn, pn, ad, e;
        public frmAddContact(string contactname, string phonenumber, string address, string email)
        {
            InitializeComponent();
            cn = contactname;
            pn = phonenumber;
            ad = address;
            e = email;
        }

        

        private void frmAddContact_Load(object sender, EventArgs e)
        {
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            DataSet t = proxy.getgroupname(frmMain._UserId);
            cbbGroup.DataSource = t.Tables[0];
            cbbGroup.DisplayMember = "GroupName";
            cbbGroup.ValueMember = "GroupName";

            txtContactName.Text = cn;
            txtPhoneNumber.Text = pn;
            txtAddress.Text = ad;
            txtEmail.Text = this.e;

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //cbbGroupID : đã binding với database, display value là group name, value là group id
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                cp.Address = txtAddress.Text;
                cp.Contactname = txtContactName.Text;
                cp.Phonenumber = txtPhoneNumber.Text;
                cp.Email = txtEmail.Text;
                gp.Groupname = cbbGroup.SelectedValue.ToString();
                up.Userid = frmMain._UserId;
                proxy.addcontact(cp, gp, up);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void cbbGroup_Click(object sender, EventArgs e)
        {
            //ngay cả khi group mới đc tạo thì vẫn đảm bảo dữ liệu là mới
            //refresh database bảng group
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            DataSet t = proxy.getgroupname(frmMain._UserId);
            cbbGroup.DataSource = t.Tables[0];
            cbbGroup.DisplayMember = "GroupName";
            cbbGroup.ValueMember = "GroupName";
        }

        private void cbbGroup_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
	}
}