﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.ServiceModel;
using Library.DAL;

namespace Client.PL.Group
{
    public partial class frmGroup : DevExpress.XtraEditors.XtraForm
    {
        Library.Contactparameter cp = new Library.Contactparameter();
        Library.Groupparameter gp = new Library.Groupparameter();

        public frmGroup()
        {
            InitializeComponent();
        }

        private void frmGroup_Load(object sender, EventArgs e)
        {
                try
                {
                    //cbbGroupID : đã binding với database, display value là group name, value là group id
                    EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                    WSHttpBinding binding = new WSHttpBinding();
                    Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                    gridControl1.DataSource = proxy.getgroupname(frmMain._UserId).Tables[0];
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
        }

        private void btnDeleteGroup_ItemClick(object sender, DevExpress.XtraBars.Ribbon.BackstageViewItemEventArgs e)
        {
            gridView1.MoveNext();
            gridView1.MovePrev();
            try
            {
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                gp.Groupname = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, colGroupName).ToString();
                proxy.deletegroup(gp);
                gridView1.DeleteRow(gridView1.FocusedRowHandle);
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void btnAddGroup_ItemClick(object sender, DevExpress.XtraBars.Ribbon.BackstageViewItemEventArgs e)
        {
            frmAddGroup fag = new frmAddGroup();
            fag.ShowDialog();
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            gridControl1.DataSource = proxy.getgroupname(frmMain._UserId).Tables[0];
        }
    }
}