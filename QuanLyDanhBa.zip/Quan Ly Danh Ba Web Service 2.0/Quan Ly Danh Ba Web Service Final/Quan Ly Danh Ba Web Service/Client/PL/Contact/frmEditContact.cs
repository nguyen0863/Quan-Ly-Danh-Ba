﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;
using System.ServiceModel;
using Library.DAL;

namespace Client.PL.Contact
{
    public partial class frmEditContact : DevExpress.XtraEditors.XtraForm
    {
        Library.Contactparameter cp = new Library.Contactparameter();
        Library.Groupparameter gp = new Library.Groupparameter();
        public string updategroupname, updatecontactname, updateuserid;

        string cn, pn, ad, e, gn, ui;
        public frmEditContact(string contactname, string phonenumber, string address, string email, string groupname, string userid)
        {
            InitializeComponent();
            cn = contactname;
            pn = phonenumber;
            ad = address;
            e = email;
            gn = groupname;
            ui = userid;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //cbbGroupID : đã binding với database, display value là group name, value là group id
                EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
                WSHttpBinding binding = new WSHttpBinding();
                Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
                cp.Address = txtAddress.Text;
                cp.Contactname = txtContactName.Text;
                cp.Phonenumber = txtPhoneNumber.Text;
                cp.Email = txtEmail.Text;
                cp.Groupname = cbbGroup.SelectedValue.ToString();
                cp.Userid = frmMain._UserId;
                proxy.editcontact(cp, gp, updategroupname, updatecontactname, updateuserid);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void cbbGroup_Click(object sender, EventArgs e)
        {
            //ngay cả khi group mới đc tạo thì vẫn đảm bảo dữ liệu là mới
            //refresh database bảng group
            EndpointAddress address = new EndpointAddress("http://localhost:8080/QuanLyDanhBa/WS");
            WSHttpBinding binding = new WSHttpBinding();
            Library.IQuanLyDanhBa proxy = ChannelFactory<Library.IQuanLyDanhBa>.CreateChannel(binding, address);
            DataSet t = proxy.getgroupname(frmMain._UserId);
            cbbGroup.DataSource = t.Tables[0];
            cbbGroup.DisplayMember = "GroupName";
            cbbGroup.ValueMember = "GroupName";
        }

        private void frmEditContact_Load(object sender, EventArgs e)
        {
            txtAddress.Text = ad;
            txtContactName.Text = cn;
            txtEmail.Text = this.e;
            txtPhoneNumber.Text = pn;
            cbbGroup.SelectedText = gn;
            updategroupname = gn;
            updatecontactname = cn;
            updateuserid = frmMain._UserId;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}