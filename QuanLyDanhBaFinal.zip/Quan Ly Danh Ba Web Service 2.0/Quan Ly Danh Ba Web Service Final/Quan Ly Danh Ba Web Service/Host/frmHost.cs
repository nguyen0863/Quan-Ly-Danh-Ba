﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.ServiceModel;

namespace Host
{
    public partial class frmHost : DevExpress.XtraEditors.XtraForm
    {
        ServiceHost host;
        readonly Type instanceType = typeof(Library.ServiceQuanLyDanhBa);
        Uri baseAddress = new Uri("http://localhost:8080/QuanLyDanhBa");

        public frmHost()
        {
            InitializeComponent();
            host = new ServiceHost(instanceType, baseAddress);
        }

        

        private void btnStart_Click(object sender, EventArgs e)
        {
            Type contractType = typeof(Library.IQuanLyDanhBa);
            host.AddServiceEndpoint(contractType, new WSHttpBinding(), "WS");
            host.Open();
            MessageBox.Show("Started");
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            host.Close();
            MessageBox.Show("Stopped");
        }
    }
}